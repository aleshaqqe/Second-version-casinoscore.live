"use strict";

/* =========================
   BOOT
   ========================= */

document.addEventListener("DOMContentLoaded", () => {
  function getCurrentGameKey() {
    const gameDataScript = document.getElementById("gamePageData");
    if (!gameDataScript) return null;

    try {
      const payload = JSON.parse(gameDataScript.textContent);
      return payload?.game?.id || null;
    } catch (error) {
      return null;
    }
  }

  function getStoredTabKey(gameId) {
    return gameId ? `activeGameTab:${gameId}` : null;
  }

  function saveActiveTab(gameId, tabName) {
    const key = getStoredTabKey(gameId);
    if (!key || !tabName) return;
    sessionStorage.setItem(key, tabName);
  }

  function getSavedActiveTab(gameId) {
    const key = getStoredTabKey(gameId);
    if (!key) return null;
    return sessionStorage.getItem(key);
  }

  function activateTab(group, target) {
    if (!group || !target) return;

    document.querySelectorAll(`[data-tab-group="${group}"]`).forEach((btn) => {
      const isActive = btn.getAttribute("data-tab-target") === target;
      btn.classList.toggle("active", isActive);
    });

    document.querySelectorAll(`[data-tab-panel-group="${group}"]`).forEach((panel) => {
      const isActive = panel.getAttribute("data-tab-panel") === target;
      panel.classList.toggle("active", isActive);
    });
  }

  const burgerBtn = document.getElementById("burgerBtn");
  const mobileMenu = document.getElementById("mobileMenu");

  if (burgerBtn && mobileMenu) {
    burgerBtn.addEventListener("click", () => {
      const isOpen = mobileMenu.classList.toggle("open");
      burgerBtn.setAttribute("aria-expanded", String(isOpen));
    });
  }

  document.querySelectorAll(".dropdown").forEach((dropdown) => {
    const trigger = dropdown.querySelector(".dropdown-trigger");
    if (!trigger) return;

    trigger.addEventListener("click", () => {
      const isOpen = dropdown.classList.toggle("open");
      trigger.setAttribute("aria-expanded", String(isOpen));
    });
  });

  const currentGameId = getCurrentGameKey();

  document.querySelectorAll("[data-tab-target]").forEach((button) => {
    button.addEventListener("click", () => {
      const target = button.getAttribute("data-tab-target");
      const group = button.getAttribute("data-tab-group");
      if (!target || !group) return;

      activateTab(group, target);

      if (group === "game-tabs" && currentGameId) {
        saveActiveTab(currentGameId, target);
      }
    });
  });

  if (currentGameId) {
    const savedTab = getSavedActiveTab(currentGameId);
    if (savedTab) {
      const matchingButton = document.querySelector(
        `[data-tab-group="game-tabs"][data-tab-target="${savedTab}"]`
      );
      if (matchingButton) activateTab("game-tabs", savedTab);
    }
  }

  attachStreamLaunchHandlers(document);
  secureAffiliateLinks(document);

  document.body.addEventListener("click", (e) => {
    const btn = e.target.closest(".js-aff-btn-secure");
    if (!btn) return;

    const b64Url = btn.getAttribute("data-b64");
    if (!b64Url) return;

    const decodedUrl = atob(b64Url);
    window.open(decodedUrl, "_blank", "noopener,noreferrer");
  });

  initDynamicGameStats();
});

/* =========================
   AFF LINKS SECURITY
   ========================= */

function secureAffiliateLinks(root = document) {
  root.querySelectorAll('a[href^="/go/"]').forEach((link) => {
    if (link.closest(".js-aff-btn-secure")) return;

    const url = link.getAttribute("href");
    if (!url) return;

    const text = link.innerHTML;
    const classes = link.className || "";
    const b64Url = btoa(url);

    const span = document.createElement("span");
    span.innerHTML = text;
    span.className = `${classes} js-aff-btn-secure`.trim();
    span.setAttribute("data-b64", b64Url);
    span.style.cursor = "pointer";

    link.replaceWith(span);
  });
}

function attachStreamLaunchHandlers(root = document) {
  root.querySelectorAll(".js-stream-launch").forEach((button) => {
    button.addEventListener("click", () => {
      const box = button.closest(".crazytime-stream-box");
      if (!box) return;

      const preview = box.querySelector(".crazytime-stream-overlay");
      const frameShell = box.querySelector(".crazytime-stream-frame-shell");
      const iframe = box.querySelector(".crazytime-stream-frame");
      const src = button.getAttribute("data-stream-src");

      if (preview) preview.classList.add("hidden");
      if (frameShell) frameShell.classList.remove("hidden");
      if (iframe && src && !iframe.src) iframe.src = src;
    });
  });
}

/* =========================
   DYNAMIC GAME STATS
   ========================= */

function initDynamicGameStats() {
  const gameDataScript = document.getElementById("gamePageData");
  if (!gameDataScript) return;

  let payload = null;
  try {
    payload = JSON.parse(gameDataScript.textContent);
  } catch (error) {
    return;
  }

  if (!payload?.game) return;

  const game = payload.game;
  const ui = payload.ui || {};
  let spinData = generateSpinData(game, game.id === "dreamcatcher" ? 520 : 120);

  const state = {
    currentTab: "temperature",
    liveUpdateInterval: null,
    ui
  };

  state.currentTab =
    document
      .querySelector('[data-tab-group="game-tabs"].tab-btn.active')
      ?.getAttribute("data-tab-target") || state.currentTab;

  document.querySelectorAll('[data-tab-group="game-tabs"]').forEach((button) => {
    button.addEventListener("click", () => {
      state.currentTab = button.getAttribute("data-tab-target") || "temperature";
    });
  });

  state.liveUpdateInterval = window.setInterval(() => {
    simulateLiveUpdate(game, spinData, state);
  }, 30000);
}

/* =========================
   UTILS
   ========================= */

function truncateLabel(value, max = 5) {
  if (!value) return "";
  return value.length > max ? `${value.slice(0, max)}…` : value;
}

function numberWithCommas(value) {
  return Number(value || 0).toLocaleString("en-US");
}

function formatTime(date) {
  const d = new Date(date);
  return d.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  });
}

function formatDate(date) {
  const d = new Date(date);
  return d.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric"
  });
}

function weightedRandom(probabilities) {
  const total = probabilities.reduce((sum, item) => sum + item, 0);
  let random = Math.random() * total;

  for (let i = 0; i < probabilities.length; i += 1) {
    random -= probabilities[i];
    if (random <= 0) return i;
  }

  return probabilities.length - 1;
}

function isBonusSegment(segmentIndex, segmentName = "") {
  return (
    segmentIndex >= 4 ||
    String(segmentName).includes("x") ||
    String(segmentName).includes("Lightning") ||
    String(segmentName).includes("Chance")
  );
}

/* =========================
   MOCK DATA CLIENT
   ========================= */

function getMultiplierPool(game, bonus) {
  if (game.id === "dreamcatcher") {
    return bonus ? [7, 14, 21, 35, 70, 140, 280, 343] : [1, 2, 3, 5, 7, 10];
  }
  return bonus ? [5, 10, 15, 20, 25, 50, 100, 200, 500] : [1, 2, 3, 5];
}

function getWinnersCount(game) {
  return game.id === "dreamcatcher"
    ? Math.floor(Math.random() * 1000 + 1)
    : Math.floor(Math.random() * 2000 + 100);
}

function getRandomMegaMultiplier() {
  const pool = ["5x", "10x", "12x", "15x", "20x", "25x", "50x", "100x"];
  return pool[Math.floor(Math.random() * pool.length)];
}

function getRandomUniqueBalls(count, min, max, exclude = []) {
  const used = new Set(exclude);
  const result = [];

  while (result.length < count) {
    const value = Math.floor(Math.random() * (max - min + 1)) + min;
    if (!used.has(value)) {
      used.add(value);
      result.push(value);
    }
  }

  return result.sort((a, b) => a - b);
}

function generateSpinData(game, count) {
  const data = [];
  const now = Date.now();

  if (game.id === "megaball") {
    for (let i = 0; i < count; i += 1) {
      const megaBallNumber = Math.floor(Math.random() * 25) + 1;
      const hasSecondMegaBall = Math.random() < 0.35;

      let secondMegaBallNumber = null;
      if (hasSecondMegaBall) {
        do {
          secondMegaBallNumber = Math.floor(Math.random() * 25) + 1;
        } while (secondMegaBallNumber === megaBallNumber);
      }

      data.push({
        time: new Date(now - i * 65000),
        megaBallNumber,
        megaBallMultiplier: getRandomMegaMultiplier(),
        secondMegaBallNumber,
        secondMegaBallMultiplier: hasSecondMegaBall ? getRandomMegaMultiplier() : null,
        balls: getRandomUniqueBalls(5, 1, 50),
        payout: Math.round(Math.random() * 5000 + 500)
      });
    }
    return data;
  }

  for (let i = 0; i < count; i += 1) {
    const segIdx = weightedRandom(game.segProbs || [100]);
    const segment = game.segments?.[segIdx] || game.name;
    const bonus = isBonusSegment(segIdx, segment);
    const multiplierPool = getMultiplierPool(game, bonus);
    const multiplier = multiplierPool[Math.floor(Math.random() * multiplierPool.length)];
    const winners = getWinnersCount(game);
    const payout = Math.round(multiplier * winners * (Math.random() * 2 + 0.5));

    const slotResult =
      game.segments?.[
        Math.floor(Math.random() * Math.min(4, game.segments.length))
      ] || game.name;

    data.push({
      time: new Date(now - i * 65000),
      slotResult,
      spinResult: segment,
      segIdx,
      multiplier,
      winners,
      payout,
      isBonus: bonus
    });
  }

  return data;
}

function generateTemperatureData(game, spinData = []) {
  if (game.id === "megaball") {
    const recent = spinData.slice(0, 120);
    const buckets = {};

    recent.forEach((spin) => {
      const key = String(spin.megaBallMultiplier || "—");
      if (!buckets[key]) {
        buckets[key] = { segment: key, spins: 0 };
      }
      buckets[key].spins += 1;
    });

    const total = recent.length || 1;

    return Object.values(buckets)
      .map((item) => {
        const percent = Number(((item.spins / total) * 100).toFixed(2));
        const diff = Number((percent - 10).toFixed(2));
        let tempClass = "temp-warm";
        if (diff >= 4) tempClass = "temp-hot";
        if (diff <= -4) tempClass = "temp-cold";

        return {
          segment: item.segment,
          spins: item.spins,
          percent,
          diff,
          tempClass
        };
      })
      .sort((a, b) => b.percent - a.percent)
      .slice(0, 8);
  }

  const items = (game.segments || []).map((segment, index) => {
    const expected = game.segProbs?.[index] || 0;
    const diff = Number((Math.random() * 4 - 2).toFixed(2));
    const actual = Number(Math.max(0, expected + diff).toFixed(2));
    const spinsSince = Math.floor(Math.random() * 30);

    let tempClass = "temp-warm";
    let iconClass = "fa-temperature-half";

    if (diff > 0.5) {
      tempClass = "temp-hot";
      iconClass = "fa-fire";
    } else if (diff < -0.5) {
      tempClass = "temp-cold";
      iconClass = "fa-snowflake";
    }

    return {
      segment,
      shortSegment: segment.length > 3 ? segment.slice(0, 3) : segment,
      color: game.segColors?.[index] || "#6b7280",
      actual,
      diff,
      spinsSince,
      tempClass,
      iconClass
    };
  });

  if (game.id === "monopoly") {
    const monopolyOrder = ["1", "5", "2 Rolls", "2", "10", "4 Rolls", "Chance"];
    return monopolyOrder
      .map((name) => items.find((item) => item.segment === name))
      .filter(Boolean);
  }

  return items;
}

function countDistribution(game, spinData) {
  if (game.id === "megaball") {
    const counts = {};
    spinData.forEach((item) => {
      const key = String(item.megaBallMultiplier || "—");
      counts[key] = (counts[key] || 0) + 1;
    });

    const total = spinData.length || 1;
    return Object.keys(counts).map((key, index) => ({
      label: key,
      color: game.segColors?.[index % (game.segColors?.length || 1)] || "#01696f",
      percent: Number(((counts[key] / total) * 100).toFixed(2))
    }));
  }

  const counts = (game.segments || []).map(
    (segment) => spinData.filter((item) => item.spinResult === segment).length
  );

  const total = counts.reduce((sum, count) => sum + count, 0);

  return (game.segments || []).map((segment, index) => ({
    label: segment,
    color: game.segColors?.[index] || "#6b7280",
    percent: total ? Number(((counts[index] / total) * 100).toFixed(2)) : 0
  }));
}

function generateStatsSummary(game, spinData) {
  if (game.id === "megaball") {
    const totalPayout = spinData.reduce((sum, item) => sum + (item.payout || 0), 0);
    const avgPayout = spinData.length ? Math.round(totalPayout / spinData.length) : 0;

    const biggestMultiplierNum = Math.max(
      ...spinData.map((item) => parseInt(String(item.megaBallMultiplier || "0"), 10) || 0),
      0
    );

    return {
      totalSpinsToday: 700 + Math.floor(Math.random() * 400),
      bonusRoundsToday: spinData.filter((item) => item.secondMegaBallNumber).length,
      biggestMultToday: `${numberWithCommas(biggestMultiplierNum)}x`,
      avgPayoutToday: numberWithCommas(avgPayout),
      rtp: `${(95 + Math.random() * 2).toFixed(2)}%`
    };
  }

  const bonusCount = spinData.filter((item) => item.isBonus).length;
  const biggestMultiplier = spinData.length
    ? Math.max(...spinData.map((item) => item.multiplier || 0))
    : 0;
  const totalPayout = spinData.reduce((sum, item) => sum + (item.payout || 0), 0);
  const avgPayout = spinData.length ? Math.round(totalPayout / spinData.length) : 0;
  const rtp = `${(96 + (Math.random() * 1.2 - 0.6)).toFixed(2)}%`;

  return {
    totalSpinsToday: 700 + Math.floor(Math.random() * 400),
    bonusRoundsToday: bonusCount,
    biggestMultToday: `${biggestMultiplier.toLocaleString("en-US")}x`,
    avgPayoutToday: avgPayout.toLocaleString("en-US"),
    rtp
  };
}

function generateBigWins(game) {
  const wins = [];

  if (game.id === "megaball") {
    for (let i = 0; i < 9; i += 1) {
      wins.push({
        segment: getRandomMegaMultiplier(),
        color: "#01696f",
        multiplier: [50, 100, 150, 200, 250, 500, 750, 1000, 2000][i],
        time: new Date(Date.now() - Math.floor(Math.random() * 86400000 * 7)),
        payout: Math.floor(Math.random() * 500000 + 10000)
      });
    }

    return wins.sort((a, b) => b.multiplier - a.multiplier);
  }

  for (let i = 0; i < 9; i += 1) {
    const segIdx = Math.floor(Math.random() * (game.segments?.length || 1));
    wins.push({
      segment: game.segments?.[segIdx] || game.name,
      color: game.segColors?.[segIdx] || "#8b5cf6",
      multiplier: [100, 200, 500, 1000, 2000, 2500, 5000, 10000, 25000][i],
      time: new Date(Date.now() - Math.floor(Math.random() * 86400000 * 7)),
      payout: Math.floor(Math.random() * 500000 + 10000)
    });
  }

  return wins.sort((a, b) => b.multiplier - a.multiplier);
}

function randomPlayerName() {
  const names = ["Joe...", "Eri...", "Mar...", "Nik...", "Har...", "Lf", "Dan...", "Zak...", "JMA", "Has..."];
  return names[Math.floor(Math.random() * names.length)];
}

/* =========================
   DREAM CATCHER EXTRA
   ========================= */

function generateDreamCatcherExtraStats(game, spinData) {
  const DREAM_EXTRA_WINDOW = 500;
  const trackedSpins = spinData.slice(0, DREAM_EXTRA_WINDOW);
  const totalSpins = trackedSpins.length;
  const multiplierKeys = ["2x", "7x"];

  const multiplierRows = multiplierKeys.map((key) => {
    const hits = trackedSpins.filter((item) => item.spinResult === key).length;
    const sharePercent = totalSpins ? Number(((hits / totalSpins) * 100).toFixed(2)) : 0;
    return { label: key, hits, total: totalSpins, sharePercent };
  });

  const matchHits = trackedSpins.filter((item) => multiplierKeys.includes(item.spinResult)).length;
  const matchPercent = totalSpins ? Number(((matchHits / totalSpins) * 100).toFixed(2)) : 0;
  const noMatchPercent = Number((100 - matchPercent).toFixed(2));

  const bestWins = [...trackedSpins]
    .sort((a, b) => (b.payout || 0) - (a.payout || 0) || (b.multiplier || 0) - (a.multiplier || 0))
    .slice(0, 5)
    .map((item) => ({
      date: new Date(item.time).toLocaleDateString("en-US", { month: "numeric", day: "numeric" }),
      time: new Date(item.time).toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
      }),
      outcome: item.spinResult,
      player: randomPlayerName(),
      amount: numberWithCommas(item.payout || 0),
      multiplier: `${item.multiplier || 0}x`,
      segIdx: item.segIdx
    }));

  return {
    totalSpins,
    bestWins,
    multiplierRows,
    matchPercent,
    noMatchPercent
  };
}

function rerenderDreamCatcherExtraOnly(game, spinData, ui) {
  const section = document.querySelector(".dream-catcher-extra-section");
  if (!section) return;

  const data = generateDreamCatcherExtraStats(game, spinData);
  section.outerHTML = renderDreamCatcherExtraStatsClient(data, game, ui);
}

function renderDreamCatcherExtraStatsClient(data, game, ui) {
  const tr = ui?.dreamcatcherStatsExtra || {};
  const common = ui?.common || {};

  const matchedTitle = tr.matchedTitle || tr.wheelMatchedTitle || "Wheel Multipliers Matched";
  const matchedText =
    tr.matchedText ||
    tr.wheelMatchedText ||
    "Compare multiplier hits against regular spins in the current sample.";
  const trackedMeta = `${tr.trackedMetaPrefix || "Past 30 minutes"} · ${data.totalSpins} ${common.spins || "Spins"}`;

  return `
    <section class="dream-catcher-extra-section">
      <article class="dream-catcher-card">
        <div class="dream-catcher-section-head">
          <h3 class="dream-catcher-title">${tr.bestWinsTitle || "Top Single-Spin Wins"}</h3>
          <p class="dream-catcher-meta">${trackedMeta}</p>
          <p class="dream-catcher-text">${tr.bestWinsText || ""}</p>
        </div>

        <div class="table-wrap dream-catcher-table-wrap">
          <table class="spin-table dream-catcher-table">
            <thead>
              <tr>
                <th class="t-left">${tr.finished || "Finished"}</th>
                <th class="t-center">${tr.outcome || "Outcome"}</th>
                <th class="t-left">${tr.player || "Player"}</th>
                <th class="t-left">${tr.wonAmount || "Won Amount"}</th>
                <th class="t-left">${tr.multiplier || "Multiplier"}</th>
              </tr>
            </thead>
            <tbody>
              ${data.bestWins.map((item) => {
                const outcomeImage = getSegmentImage(game, item.outcome);
                return `
                  <tr>
                    <td class="t-left">${item.date}<br><span class="text-soft" style="font-size:0.75rem;">${item.time}</span></td>
                    <td class="t-center">
                      ${
                        outcomeImage
                          ? `<span class="result-badge result-badge-image dream-catcher-badge"><img src="${outcomeImage}" alt="${item.outcome}" loading="lazy" decoding="async" class="result-badge-img"></span>`
                          : `<span class="result-badge dream-catcher-badge" style="background:#6b7280;">${item.outcome}</span>`
                      }
                    </td>
                    <td class="t-left">${item.player}</td>
                    <td class="t-left"><strong>${item.amount}</strong></td>
                    <td class="t-left"><span class="monopoly-multiplier-pill">${item.multiplier}</span></td>
                  </tr>
                `;
              }).join("")}
            </tbody>
          </table>
        </div>
      </article>

      <article class="dream-catcher-card">
        <div class="dream-catcher-section-head">
          <h3 class="dream-catcher-title">${tr.wheelStatsTitle || "Wheel Multipliers Stats"}</h3>
          <p class="dream-catcher-meta">${trackedMeta}</p>
          <p class="dream-catcher-text">${tr.wheelStatsText || ""}</p>
        </div>

        <div class="dream-catcher-wheel-list">
          ${data.multiplierRows.map((row) => {
            const wheelImage = getSegmentImage(game, row.label);
            const barWidth = row.sharePercent > 0 ? Math.max(row.sharePercent, 4) : 0;

            return `
              <div class="dream-catcher-wheel-item">
                <div class="dream-catcher-wheel-top">
                  <div class="dream-catcher-wheel-label">
                    ${
                      wheelImage
                        ? `<img src="${wheelImage}" alt="${row.label}" loading="lazy" decoding="async" class="dream-catcher-wheel-thumb">`
                        : ""
                    }
                    <span>${row.label}</span>
                  </div>
                  <strong>${row.hits}/${row.total} · ${row.sharePercent}%</strong>
                </div>
                <div class="dream-catcher-bar">
                  <div class="dream-catcher-bar-fill" style="width:${barWidth}%"></div>
                </div>
              </div>
            `;
          }).join("")}
        </div>
      </article>

      <article class="dream-catcher-card">
        <div class="dream-catcher-section-head">
          <h3 class="dream-catcher-title">${matchedTitle}</h3>
          <p class="dream-catcher-meta">${trackedMeta}</p>
          <p class="dream-catcher-text">${matchedText}</p>
        </div>

        <div class="dream-catcher-match-list">
          <div class="dream-catcher-match-item">
            <div class="dream-catcher-match-row">
              <span>${tr.match || "Match"}</span>
              <strong>${data.matchPercent}%</strong>
            </div>
            <div class="dream-catcher-bar dream-catcher-bar--match">
              <div class="dream-catcher-bar-fill" style="width:${data.matchPercent}%"></div>
            </div>
          </div>

          <div class="dream-catcher-match-item">
            <div class="dream-catcher-match-row">
              <span>${tr.noMatch || "No Match"}</span>
              <strong>${data.noMatchPercent}%</strong>
            </div>
            <div class="dream-catcher-bar dream-catcher-bar--nomatch">
              <div class="dream-catcher-bar-fill" style="width:${data.noMatchPercent}%"></div>
            </div>
          </div>
        </div>
      </article>
    </section>
  `;
}

/* =========================
   IMAGES / BADGES
   ========================= */

function getSegmentImage(game, segmentName) {
  if (!game) return "";

  if (game.id === "monopoly") {
    const monopolySegmentImages = {
      "1": "img/monopoly/temperature/one.webp",
      "2": "img/monopoly/temperature/two.webp",
      "5": "img/monopoly/temperature/five.webp",
      "10": "img/monopoly/temperature/ten.webp",
      "2 Rolls": "img/monopoly/temperature/two-rolls.webp",
      "4 Rolls": "img/monopoly/temperature/four-rolls.webp",
      Chance: "img/monopoly/temperature/chance.webp"
    };
    return monopolySegmentImages[segmentName] || "";
  }

  if (game.spinResultImages && game.spinResultImages[segmentName]) {
    return game.spinResultImages[segmentName].startsWith("/")
      ? game.spinResultImages[segmentName]
      : `/${game.spinResultImages[segmentName]}`;
  }

  if (game.segmentImages && game.segmentImages[segmentName]) {
    return game.segmentImages[segmentName].startsWith("/")
      ? game.segmentImages[segmentName]
      : `/${game.segmentImages[segmentName]}`;
  }

  return "";
}

function getSlotResultImage(game, segmentName) {
  if (!game || !game.slotResultImages) return "";
  const image = game.slotResultImages[segmentName] || "";
  return image ? (image.startsWith("/") ? image : `/${image}`) : "";
}

function renderSegmentBadge(game, segmentName, color, extraClass = "", imageType = "spin") {
  const image =
    imageType === "slot"
      ? getSlotResultImage(game, segmentName)
      : getSegmentImage(game, segmentName);

  if (image) {
    return `
      <span class="result-badge result-badge-image ${extraClass}">
        <img src="${image}" alt="${segmentName}" loading="lazy" class="result-badge-img">
      </span>
    `;
  }

  return `
    <span class="result-badge ${extraClass}" style="background:${color};">
      ${truncateLabel(segmentName, 8)}
    </span>
  `;
}

function renderChartLabel(game, segmentName) {
  const image = getSegmentImage(game, segmentName);

  if (image) {
    return `
      <span class="chart-label chart-label-image">
        <img src="${image}" alt="${segmentName}" loading="lazy" class="chart-label-img">
      </span>
    `;
  }

  return `<span class="chart-label">${truncateLabel(segmentName)}</span>`;
}

function renderTemperatureSegment(game, segmentName, color, shortLabel) {
  const image = getSegmentImage(game, segmentName);

  if (image) {
    return `
      <div class="temp-segment temp-segment-image">
        <img src="${image}" alt="${segmentName}" loading="lazy" decoding="async" class="temp-segment-img">
      </div>
    `;
  }

  return `<div class="temp-segment" style="background:${color};">${shortLabel}</div>`;
}

/* =========================
   RERENDER PANELS
   ========================= */

function rerenderTemperaturePanel(game, ui = {}, spinData = []) {
  const panel = document.querySelector('[data-tab-panel="temperature"][data-tab-panel-group="game-tabs"]');
  if (!panel) return;

  const tr = ui?.gamePanels || {};

  if (game.id === "megaball") {
    const items = generateTemperatureData(game, spinData);

    panel.innerHTML = `
      <h2 class="panel-title">${tr.temperatureTitle || "Hot & Cold Multipliers"}</h2>
      <p class="panel-subtitle">
        ${tr.temperatureSubtitle || "Track the hottest and coldest Mega Ball multipliers based on recent rounds."}
      </p>

      <div class="temp-grid mega-temp-grid">
        ${items.map((item) => `
          <div class="temp-card">
            <div class="temp-segment mega-temp-segment">${item.segment}</div>
            <div class="temp-value ${item.tempClass || ""}">${item.percent}%</div>
            <div class="temp-diff ${item.diff >= 0 ? "positive" : "negative"}">
              ${item.diff >= 0 ? "+" : ""}${item.diff}%
            </div>
            <div class="temp-spins">${numberWithCommas(item.spins)} spins</div>
          </div>
        `).join("")}
      </div>
    `;
    return;
  }

  const subtitle =
    tr.temperatureSubtitle ||
    "Live segment temperature highlights hot and cold outcomes based on recent spins versus expected probability.";
  const spinsSinceTpl = tr.temperatureSpinsSince || "{n} spins since";
  const temperatureData = generateTemperatureData(game, spinData);

  panel.innerHTML = `
    <h2 class="panel-title">Segment Temperature</h2>
    <p class="panel-subtitle">${subtitle}</p>

    <div class="temp-grid">
      ${temperatureData.map((item) => {
        const spinsSinceText = spinsSinceTpl.replace("{n}", item.spinsSince);
        return `
          <div class="temp-card">
            ${renderTemperatureSegment(game, item.segment, item.color, item.shortSegment)}
            <div class="temp-value ${item.tempClass}">${item.actual}%</div>
            <div class="temp-diff ${item.diff >= 0 ? "positive" : "negative"}">
              ${item.diff >= 0 ? "+" : ""}${item.diff}%
            </div>
            <div class="temp-spins">${spinsSinceText}</div>
            <i class="fas ${item.iconClass} ${item.tempClass} temp-icon"></i>
          </div>
        `;
      }).join("")}
    </div>
  `;
}

function rerenderHistoryPanel(game, spinData, ui = {}) {
  const panel = document.querySelector('[data-tab-panel="history"][data-tab-panel-group="game-tabs"]');
  if (!panel) return;

  const tr = ui?.gamePanels || {};
  const subtitle =
    tr.historySubtitle ||
    "Explore the latest spin history with real-time results, multipliers, winners, and payouts.";

  const pageData = spinData.slice(0, 25);

  if (game.id === "megaball") {
    panel.innerHTML = `
      <h2 class="panel-title">Recent Spin History</h2>
      <p class="panel-subtitle">${subtitle}</p>

      <div class="table-wrap">
        <table class="spin-table">
          <thead>
            <tr>
              <th class="t-left">${tr.occurredAt || "Occurred At"}</th>
              <th class="t-left">Mega Ball</th>
              <th class="t-left">2nd Mega Ball</th>
              <th class="t-left">Balls</th>
              <th class="t-right">${tr.totalPayout || "Total Payout"}</th>
            </tr>
          </thead>
          <tbody>
            ${pageData.map((spin) => {
              const megaBallMarkup = `
                <div class="mega-ball-inline">
                  <span class="result-badge result-badge-ball">${spin.megaBallNumber ?? "—"}</span>
                  <span class="mega-ball-multiplier">(${spin.megaBallMultiplier ?? "—"})</span>
                </div>
              `;

              const secondMegaBallMarkup = spin.secondMegaBallNumber
                ? `
                  <div class="mega-ball-inline">
                    <span class="result-badge result-badge-ball">${spin.secondMegaBallNumber}</span>
                    <span class="mega-ball-multiplier">(${spin.secondMegaBallMultiplier ?? "—"})</span>
                  </div>
                `
                : `<span class="text-soft">—</span>`;

              const ballsMarkup = `
                <div class="mega-balls-list">
                  ${(spin.balls || [])
                    .map((ball) => `<span class="result-badge result-badge-ball">${ball}</span>`)
                    .join("")}
                </div>
              `;

              return `
                <tr>
                  <td class="t-left text-soft">${formatTime(spin.time)}</td>
                  <td class="t-left">${megaBallMarkup}</td>
                  <td class="t-left">${secondMegaBallMarkup}</td>
                  <td class="t-left mega-balls-cell">${ballsMarkup}</td>
                  <td class="t-right text-green" style="font-weight:600;">
                    €${numberWithCommas(spin.payout ?? 0)}
                  </td>
                </tr>
              `;
            }).join("")}
          </tbody>
        </table>
      </div>
    `;
    return;
  }

  const showSlotResult = game.id !== "monopoly" && !game.hideSlotResult;
  const showSpecialResult = game.id === "dreamcatcher";

  panel.innerHTML = `
    <h2 class="panel-title">Recent Spin History</h2>
    <p class="panel-subtitle">${subtitle}</p>

    <div class="table-wrap">
      <table class="spin-table">
        <thead>
          <tr>
            <th class="t-left">${tr.occurredAt || "Occurred At"}</th>
            ${showSlotResult ? `<th class="t-center">${tr.slotResult || "Slot Result"}</th>` : ""}
            <th class="t-center">${tr.spinResult || "Spin Result"}</th>
            ${showSpecialResult ? `<th class="t-center">${tr.specialResult || "Special Result"}</th>` : ""}
            <th class="t-right">${tr.multiplier || "Multiplier"}</th>
            <th class="t-right">${tr.totalWinners || "Total Winners"}</th>
            <th class="t-right">${tr.totalPayout || "Total Payout"}</th>
          </tr>
        </thead>

        <tbody>
          ${pageData.map((spin) => {
            const isSpecial =
              showSpecialResult && (spin.spinResult === "2x" || spin.spinResult === "7x");

            const segmentIndex = game.segments.indexOf(spin.spinResult);
            const slotIdx = game.segments.indexOf(spin.slotResult);

            const spinColor = segmentIndex >= 0 ? game.segColors[segmentIndex] : "#6b7280";
            const slotColor = slotIdx >= 0 ? game.segColors[slotIdx] : "#6b7280";

            return `
              <tr>
                <td class="t-left text-soft">${formatTime(spin.time)}</td>

                ${showSlotResult ? `
                  <td class="t-center">
                    ${isSpecial ? "" : renderSegmentBadge(game, spin.slotResult, slotColor, "result-badge-slot", "slot")}
                  </td>
                ` : ""}

                <td class="t-center">
                  ${
                    spin.isBonus
                      ? renderSegmentBadge(game, spin.spinResult, spinColor, "result-badge-bonus-image", "spin")
                      : renderSegmentBadge(game, spin.spinResult, spinColor, "", "spin")
                  }
                </td>

                ${showSpecialResult ? `
                  <td class="t-center">
                    ${isSpecial ? `<span class="special-result-pill">${spin.spinResult}</span>` : ""}
                  </td>
                ` : ""}

                <td class="t-right ${!isSpecial && spin.multiplier >= 50 ? "text-gold" : ""}" style="font-weight:600;">
                  ${isSpecial ? "" : `${spin.multiplier}x`}
                </td>

                <td class="t-right text-soft">
                  ${isSpecial ? "" : numberWithCommas(spin.winners)}
                </td>

                <td class="t-right text-green" style="font-weight:600;">
                  ${isSpecial ? "" : `$${numberWithCommas(spin.payout)}`}
                </td>
              </tr>
            `;
          }).join("")}
        </tbody>
      </table>
    </div>
  `;
}

function rerenderStatsPanel(game, spinData, ui = {}) {
  const panel = document.querySelector('[data-tab-panel="stats"][data-tab-panel-group="game-tabs"]');
  if (!panel) return;

  const tr = ui?.gamePanels || {};
  const distribution = countDistribution(game, spinData);
  const summary = generateStatsSummary(game, spinData);
  const highestPercent = Math.max(...distribution.map((item) => item.percent), 1);

  const rtpBasedOn = tr.rtpBasedOn || "Based on last 1,000 spins";
  const totalSpinsTodayLabel = tr.summaryTotalSpinsToday || "Total Spins Today";
  const bonusRoundsLabel = tr.summaryBonusRounds || "Bonus Rounds";
  const biggestMultiplierLabel = tr.summaryBiggestMultiplier || "Biggest Multiplier";
  const avgPayoutLabel = tr.summaryAvgPayout || "Avg. Payout";

  let extraHtml = "";

  if (game.id === "crazytime") {
    const crazyTimeExtra = panel.querySelector(".crazytime-bonus-section");
    extraHtml = crazyTimeExtra ? crazyTimeExtra.outerHTML : "";
  }

  if (game.id === "dreamcatcher" && typeof renderDreamCatcherExtraStatsClient === "function") {
    const dreamCatcherData = generateDreamCatcherExtraStats(game, spinData);
    extraHtml = renderDreamCatcherExtraStatsClient(dreamCatcherData, game, ui);
  }

  panel.innerHTML = `
    <div class="stats-main-grid">
      <div class="stats-grid-card">
        <h2 class="panel-title">Result Distribution</h2>
        <div class="chart-scroll">
          <div class="chart-box">
            ${distribution.map((item) => {
              const height = Math.max((item.percent / highestPercent) * 100, 4);
              return `
                <div class="chart-col">
                  <span class="chart-percent">${item.percent}%</span>
                  <div class="chart-bar-wrap">
                    <div class="chart-bar" style="height:${height}%; background:${item.color};"></div>
                  </div>
                  ${renderChartLabel(game, item.label)}
                </div>
              `;
            }).join("")}
          </div>
        </div>
      </div>

      <div class="stats-grid-card">
        <h2 class="panel-title">Return to Player</h2>
        <div class="rtp-card-body">
          <div class="rtp-center">
            <div class="rtp-value">${summary.rtp}</div>
            <p class="rtp-text">${rtpBasedOn}</p>
          </div>
        </div>
      </div>
    </div>

    <div class="stats-summary-grid">
      <div class="stats-grid-card summary-card">
        <p class="summary-label">${totalSpinsTodayLabel}</p>
        <p class="summary-value">${numberWithCommas(summary.totalSpinsToday)}</p>
      </div>

      <div class="stats-grid-card summary-card">
        <p class="summary-label">${bonusRoundsLabel}</p>
        <p class="summary-value purple">${numberWithCommas(summary.bonusRoundsToday)}</p>
      </div>

      <div class="stats-grid-card summary-card">
        <p class="summary-label">${biggestMultiplierLabel}</p>
        <p class="summary-value gold">${summary.biggestMultToday}</p>
      </div>

      <div class="stats-grid-card summary-card">
        <p class="summary-label">${avgPayoutLabel}</p>
        <p class="summary-value green">${summary.avgPayoutToday}</p>
      </div>
    </div>

    ${extraHtml}
  `;

  if (typeof secureAffiliateLinks === "function") {
    secureAffiliateLinks(panel);
  }
}

function rerenderBigWinsPanel(game, ui = {}) {
  const panel = document.querySelector('[data-tab-panel="bigwins"][data-tab-panel-group="game-tabs"]');
  if (!panel) return;

  const tr = ui?.gamePanels || {};
  const watchLabel = tr.watch || "Watch";
  const wins = generateBigWins(game);

  panel.innerHTML = `
    <h2 class="panel-title">Top Multiplier Wins</h2>

    <div class="bigwins-grid">
      ${wins.map((win, index) => `
        <article class="stats-grid-card bigwin-card">
          <div class="bigwin-top">
            <span class="bigwin-date">${formatDate(win.time)}</span>
            <span class="bigwin-rank ${index < 3 ? "top" : ""}">#${index + 1}</span>
          </div>

          <div class="bigwin-main">
            <span class="bigwin-segment">
              ${
                getSegmentImage(game, win.segment)
                  ? `<img src="${getSegmentImage(game, win.segment)}" alt="${win.segment}" loading="lazy" class="bigwin-segment-img">`
                  : truncateLabel(win.segment, 4)
              }
            </span>

            <div>
              <div class="bigwin-multiplier">${numberWithCommas(win.multiplier)}x</div>
              <div class="bigwin-label">${win.segment}</div>
            </div>
          </div>

          <div class="bigwin-bottom">
            <span class="bigwin-payout">$${numberWithCommas(win.payout)}</span>
            <span class="bigwin-watch"><i class="fas fa-play-circle"></i> ${watchLabel}</span>
          </div>
        </article>
      `).join("")}
    </div>
  `;
}

/* =========================
   LIVE UPDATE
   ========================= */

function simulateLiveUpdate(game, spinData, state) {
  if (game.id === "megaball") {
    const megaBallNumber = Math.floor(Math.random() * 25) + 1;
    const hasSecondMegaBall = Math.random() < 0.35;

    let secondMegaBallNumber = null;
    if (hasSecondMegaBall) {
      do {
        secondMegaBallNumber = Math.floor(Math.random() * 25) + 1;
      } while (secondMegaBallNumber === megaBallNumber);
    }

    spinData.unshift({
      time: new Date(),
      megaBallNumber,
      megaBallMultiplier: getRandomMegaMultiplier(),
      secondMegaBallNumber,
      secondMegaBallMultiplier: hasSecondMegaBall ? getRandomMegaMultiplier() : null,
      balls: getRandomUniqueBalls(5, 1, 50),
      payout: Math.round((Math.random() * 4000 + 500) * (Math.random() * 2 + 0.8))
    });
  } else {
    const segIdx = weightedRandom(game.segProbs || [100]);
    const segment = game.segments?.[segIdx] || game.name;
    const bonus = isBonusSegment(segIdx, segment);

    const multiplierPool = getMultiplierPool(game, bonus);
    const multiplier = multiplierPool[Math.floor(Math.random() * multiplierPool.length)];
    const winners = getWinnersCount(game);
    const payout = Math.round(multiplier * winners * (Math.random() * 2 + 0.5));

    const slotResult =
      game.segments?.[
        Math.floor(Math.random() * Math.min(4, game.segments.length))
      ] || game.name;

    spinData.unshift({
      time: new Date(),
      slotResult,
      spinResult: segment,
      segIdx,
      multiplier,
      winners,
      payout,
      isBonus: bonus
    });
  }

  if (spinData.length > 800) spinData.pop();

  rerenderTemperaturePanel(game, state.ui, spinData);

  if (state.currentTab === "history") {
    rerenderHistoryPanel(game, spinData, state.ui);
  }

  if (state.currentTab === "stats") {
    rerenderStatsPanel(game, spinData, state.ui);
  }

  if (state.currentTab === "bigwins") {
    rerenderBigWinsPanel(game, state.ui);
  }

  if (game.id === "dreamcatcher") {
    rerenderDreamCatcherExtraOnly(game, spinData, state.ui);
  }
}